#define RAYGUI_IMPLEMENTATION
#include <raylib.h>
#include <raygui.h>
#include <string>
#include <cstdio>

int main(){
	const int TextureNum = 5;
	const int BeginTextureIndex = 0;
	const int EndTextureIndex = TextureNum - 1;
	
	const char* TextureName[TextureNum] = {"1.png","2.png","3.png","4.png","5.png"}; //图片名称数组
	
	int TextureIndex = 0;
	
	InitWindow(1200,800,""); //初始化raylib窗口
	SetTraceLogLevel(LOG_WARNING); //在控制台窗口中只显示警告和错误信息
	SetTargetFPS(50); //设置帧率为50fps
	Texture2D texture[TextureNum];
	
	for(int i = 0;i <= TextureNum - 1;i++){ //加载所有的图片
		std::string temp = "texture/";temp += TextureName[i];
		texture[i] = LoadTexture(temp.c_str());
	}
	int fileSize;
	unsigned char *fontFileData = LoadFileData("./font/JianZhongChangGui.otf", &fileSize);
	int codepointsCount;
	char text[]="上下一页";
	int *codepoints=LoadCodepoints(text,&codepointsCount); // 读取仅码点表中各字符的字体
	Font font = LoadFontFromMemory(".otf",fontFileData,fileSize,32,codepoints,codepointsCount); // 释放码点表
	UnloadCodepoints(codepoints);
	GuiSetFont(font); //将字体运用到GUI控件中
	
	GuiSetStyle(DEFAULT, TEXT_SIZE, 32); // 所有按钮文字都用 32px 显示
	
	while (!WindowShouldClose())    //当用户关闭窗口或者按下ESC键时返回true，否则返回false
	{
		BeginDrawing(); //准备进行帧的绘制
		
		ClearBackground(WHITE); //清除之前帧绘制的内容
		DrawTexture(texture[TextureIndex],0,0,WHITE);
		if(TextureIndex == BeginTextureIndex) GuiDisable();
		if(GuiButton((Rectangle){ 20, 740, 120, 45 }, "上一页")){
			TextureIndex--;
		}
		if(TextureIndex == BeginTextureIndex) GuiEnable();
		
		if(TextureIndex == EndTextureIndex) GuiDisable();
		if(GuiButton((Rectangle){ 1020, 740, 120, 45 }, "下一页")){
			TextureIndex++;
		}
		if(TextureIndex == EndTextureIndex) GuiEnable();
		
		EndDrawing(); //完成帧的绘制，并根据设置的帧率延时（自动暂停一段时间，以满足帧率要求）。
	}
	UnloadFont(font);
	for (int i = 0; i < TextureNum; i++) UnloadTexture(texture[i]);
	CloseWindow();
	return 0;
}
